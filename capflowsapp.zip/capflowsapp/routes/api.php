<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\Businesslist; // make sure you import this

Route::get('/sanctum/csrf-cookie', function () {
    return response()->json(['message' => 'CSRF cookie set']);
});

// Public routes
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {

    Route::get('/user', function () {
        return auth()->user()->load('user_roles')->load('businesses_one');
        //  $user = auth()->user()->load(['user_roles', 'businesses_one']);
    });

    Route::get('/businesses', [Businesslist::class, 'index']);
    Route::post('/newbusinesses', [Businesslist::class, 'store']);
    Route::get('/businessinfo/{id}', [Businesslist::class, 'business_details']);
    Route::post('/switchBusiness/{id}', [Businesslist::class, 'switchBusiness']);
    Route::put('/updatebusiness/{id}', [Businesslist::class, 'updatebusiness']);
    Route::delete('/deletebusiness/{id}', [Businesslist::class, 'deleteBusiness']);
    Route::put('/suspendBusiness/{id}', [Businesslist::class, 'suspendBusiness']);
});
