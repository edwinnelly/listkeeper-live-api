<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product_sub_child_categories extends Model
{
    //
}
