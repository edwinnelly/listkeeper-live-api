<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendor_debt_payments extends Model
{
    //
}
