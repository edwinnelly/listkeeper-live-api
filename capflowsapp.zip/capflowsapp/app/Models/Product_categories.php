<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product_categories extends Model
{
    //


    protected $fillable = [
        'name',
        'slug',
        'description',

    ];

   public function products()
    {
        return $this->hasMany(Product_list::class, 'category_id');
    }
}
