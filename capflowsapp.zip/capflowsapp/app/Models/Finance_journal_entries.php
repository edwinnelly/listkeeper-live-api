<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Finance_journal_entries extends Model
{
    //
}
