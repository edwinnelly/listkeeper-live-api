<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class purchase_orders extends Model
{
    //
}
