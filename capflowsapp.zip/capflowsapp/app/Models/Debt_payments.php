<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Debt_payments extends Model
{
    //
}
