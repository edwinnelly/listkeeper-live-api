<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Invoice_payments_installment extends Model
{
    //
}
