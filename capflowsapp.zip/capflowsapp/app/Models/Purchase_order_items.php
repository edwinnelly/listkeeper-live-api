<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Purchase_order_items extends Model
{
    //
}
