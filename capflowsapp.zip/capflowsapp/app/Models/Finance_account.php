<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Finance_account extends Model
{
    //
}
