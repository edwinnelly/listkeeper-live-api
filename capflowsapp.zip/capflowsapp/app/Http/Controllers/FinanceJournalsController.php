<?php

namespace App\Http\Controllers;

use App\Models\Finance_journals;
use Illuminate\Http\Request;

class FinanceJournalsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Finance_journals $finance_journals)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Finance_journals $finance_journals)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Finance_journals $finance_journals)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Finance_journals $finance_journals)
    {
        //
    }
}
