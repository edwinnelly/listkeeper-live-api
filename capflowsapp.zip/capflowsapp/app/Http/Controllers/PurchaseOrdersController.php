<?php

namespace App\Http\Controllers;

use App\Models\purchase_orders;
use Illuminate\Http\Request;

class PurchaseOrdersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(purchase_orders $purchase_orders)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(purchase_orders $purchase_orders)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, purchase_orders $purchase_orders)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(purchase_orders $purchase_orders)
    {
        //
    }
}
