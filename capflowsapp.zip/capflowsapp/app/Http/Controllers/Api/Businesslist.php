<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Business_list; // make sure model is imported
use App\Models\Business_locations;
use App\Models\Roles;
use App\Models\Subscriptions;
use Illuminate\Support\Str;
use App\Models\User;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\JsonResponse;

class Businesslist extends Controller
{
    /**
     * Fetch all businesses linked to the logged-in account
     */

    public function index()
    {
        try {
            $userId = Auth::id();

            // Count total businesses first
            $total = Business_list::where('owner_id', $userId)->count();

            // Threshold to decide streaming vs normal
            $threshold = 1000;

            if ($total <= $threshold) {
                // Small dataset: fetch normally
                $businesses = Business_list::where('owner_id', $userId)
                    ->orderBy('id', 'asc')
                    ->get()
                    ->map(function ($business) {
                        $business->ekey = Crypt::encrypt($business->id);
                        return $business;
                    });

                return response()->json([
                    'status' => true,
                    'message' => 'Business list fetched successfully',
                    'data' => $businesses,
                ], 200);
            } else {
                // Large dataset: stream JSON
                return Response::stream(function () use ($userId) {
                    echo '[';
                    $first = true;

                    Business_list::where('owner_id', $userId)
                        ->orderBy('id', 'asc')
                        ->chunk(1000, function ($businesses) use (&$first) {
                            foreach ($businesses as $business) {
                                $business->ekey = Crypt::encrypt($business->id);

                                if (!$first) {
                                    echo ',';
                                } else {
                                    $first = false;
                                }

                                echo json_encode($business);
                            }
                        });

                    echo ']';
                }, 200, [
                    'Content-Type' => 'application/json',
                    'Cache-Control' => 'no-cache',
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Error in Businesslist@getBusinesses: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'An error occurred while fetching business data.'
            ], 500);
        }
    }


    public function store(Request $request)
    {
        // Validate request data
        $validated = $request->validate([
            'business_name' => 'required|string|max:255|unique:business_lists,business_name,NULL,id,owner_id,' . Auth::id(),
            'address' => 'required|string|max:500',
            'website' => 'nullable|url|max:255',
            'phone' => 'required|string|max:20',
            'slug' => 'required|string|max:255',
            'about_business' => 'nullable|string',
            'country' => 'required|string|max:100',
            'state' => 'required|string|max:100',
            'city' => 'required|string|max:100',
            'subscription_plan' => 'required|string|max:100',
            'currency' => 'required|string|max:10',
            'language' => 'required|string|max:50',
            'industry_type' => 'required|string|max:150',
            'logo' => 'nullable|mimetypes:image/avif,image/jpeg,image/png,image/webp|max:2048',
        ]);

        try {
            // Check business limit
            $count_business = Business_list::where('owner_id', Auth::id())->count();
            if ($count_business >= 5) {
                return response()->json([
                    'status' => false,
                    'message' => 'Business limit reached, max allowed is 5'
                ], 400);
            }

            DB::beginTransaction();

            // Create unique business key
            $business_key = (string) Str::uuid();

            // Create business
            $business = new Business_list($validated);
            $business->owner_id = Auth::id();
            $business->business_key = $business_key;

            // Handle logo upload
            if ($request->hasFile('logo')) {
                $file = $request->file('logo');
                $filename = time() . '_' . preg_replace('/\s+/', '_', $file->getClientOriginalName());
                $file->storeAs('business_logo', $filename, 'public');
                $business->logo = 'business_logo/' . $filename;
            }

            $business->save();

            // Create default location
            $default_location = new Business_locations();
            $default_location->business_key = $business_key;
            $default_location->owner_id = Auth::id();
            $default_location->location_name = 'Main Branch';
            $default_location->head_office = 'yes';
            $default_location->manager_id = Auth::id();
            $default_location->phone = $validated['phone'];
            $default_location->location_id = rand(12345678, 1234567890);
            $default_location->save();

            // Create subscription
            $subscription = new Subscriptions();
            $subscription->owner_id = Auth::id();
            $subscription->business_key = $business_key;
            $subscription->plan_name = 'Basic';
            $subscription->plan_code = 'basic';
            $subscription->amount = 0;
            $subscription->start_date = now();
            $subscription->end_date = now()->addDays(30);
            $subscription->save();

            // Assign role if not exists
            // $existingRole = Roles::where('owner_id', Auth::id())
            //     ->where('user_id', Auth::id())
            //     ->where('business_key', $business_key)
            //     ->first();

            // if (!$existingRole) {
            //     Roles::create([
            //         'owner_id' => Auth::id(),
            //         'user_id' => Auth::id(),
            //         'business_key' => $business_key
            //     ]);
            // }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Business created successfully',
                'data' => $business
                // 'datas' => $ren,
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in Businesslist@store: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'An error occurred while creating the business',
                'error' => $e->getMessage()
            ], 500);
        }
    }



    //get the business info
    public function business_details($id)
    {
        try {
            // Decrypt business key if encrypted
            $decryptedId = Crypt::decrypt($id); // remove Crypt if not encrypted

            // Check if business exists for the authenticated user
            $business = Business_list::where('owner_id', Auth::id())
                ->where('id', $decryptedId)
                ->first();

            if (!$business) {
                return response()->json([
                    'message' => 'Business not found.'
                ], 404);
            }

            // Count locations
            $totalLocations = Business_locations::where('owner_id', Auth::id())
                ->where('business_key', $business->business_key)
                ->count();

            $activeLocations = Business_locations::where('owner_id', Auth::id())
                ->where('business_key', $business->business_key)
                ->where('status', 'active')
                ->count();

            $inactiveLocations = Business_locations::where('owner_id', Auth::id())
                ->where('business_key', $business->business_key)
                ->where('status', 'inactive')
                ->count();

            // Get subscription
            $subscription = Subscriptions::where('owner_id', Auth::id())
                ->where('business_key', $business->business_key)
                ->first();

            // Return JSON in expected structure
            return response()->json([
                'business' => [
                    'id' => $business->id,
                    'name' => $business->business_name,
                    'logo' => $business->logo,
                    'bussiness_key' => $business->business_key,
                    'slug' => $business->slug,
                    'industry_type' => $business->industry_type,
                    'website' => $business->website,
                    'phone' => $business->phone,
                    'state' => $business->state,
                    'city' => $business->city,
                    'country' => $business->country,
                    'address' => $business->address,
                    'subscription' => $business->subscription_plan,
                    'currency' => $business->currency,
                    'about_business' => $business->about_business,
                    'created_at' => $business->created_at,
                    'status' => $business->status,

                    'description' => $business->description,
                    'stats' => [
                        'totalLocations' => $totalLocations,
                        'activeLocations' => $activeLocations,
                        'inactiveLocations' => $inactiveLocations,
                    ],
                    'details' => [
                        // 'website' => $business->website ?? '',
                        'country' => $business->country ?? '',
                        'currency' => $business->currency ?? '',
                        'businessType' => $business->industry_type ?? '',

                        'address' => $business->address ?? '',
                        'creation' => $business->created_at ? $business->created_at->format('F j, Y') : '',
                    ],

                ]
            ]);
        } catch (\Exception $e) {
            Log::error('Business fetch error: ' . $e->getMessage());

            return response()->json([
                'message' => 'An error occurred while fetching business.'
            ], 500);
        }
    }


    //switch business
    public function switchBusiness(string $id): JsonResponse
    {
        try {
            // Ensure the user is authenticated
            $user = Auth::user();
            if (!$user) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'Unauthorized. Please log in.',
                ], 401);
            }

            // Find the business that belongs to the authenticated user
            $business = Business_list::where('owner_id', $user->id)
                ->where('business_key', $id)
                ->first();

            if (!$business) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'Business not found.',
                ], 404);
            }

            // Update the user's active business
            $user->update([
                'active_business_key' => $id,
                'business_key' => $id,
            ]);

            return response()->json([
                'status'  => 'success',
                'message' => 'Business switched successfully.',
                'active_business_key' => $id,
            ], 200);
        } catch (\Throwable $e) {
            return response()->json([
                'status'  => 'error',
                'message' => 'An unexpected error occurred while switching business.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }


    // public function updatebusiness(Request $request, $id)
    // {
    //     try {
    //         // 🔐 Decrypt ID if encrypted
    //         $decryptedId = Crypt::decrypt($id); // remove if ID isn't encrypted

    //         // 🔍 Find the business that belongs to the logged-in user
    //         $business = Business_list::where('owner_id', Auth::id())
    //             ->where('id', $decryptedId)
    //             ->first();

    //         if (!$business) {
    //             return response()->json([
    //                 'message' => 'Business not found.'
    //             ], 404);
    //         }

    //         // ✅ Validate incoming data
    //         $validatedData = $request->validate([
    //             'business_name' => 'sometimes|string|max:255',
    //             'industry_type' => 'sometimes|string|max:255',
    //             'website' => 'nullable|url|max:255',
    //             'phone' => 'nullable|string|max:20',
    //             'state' => 'nullable|string|max:255',
    //             'city' => 'nullable|string|max:255',
    //             'country' => 'nullable|string|max:255',
    //             'address' => 'nullable|string|max:500',
    //             'currency' => 'nullable|string|max:10',
    //             'about_business' => 'nullable|string',
    //             'description' => 'nullable|string',
    //             'logo' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
    //             // 'logo' => 'nullable', // 👈 changed
    //         ]);

    //         // 🖼️ Handle logo upload (if provided)
    //         if ($request->hasFile('logo')) {
    //             $file = $request->file('logo');
    //             $path = $file->store('business_logo', 'public');
    //             $validatedData['logo'] = $path;
    //         }

    //         // 💾 Update business
    //         $business->update($validatedData);

    //         return response()->json([
    //             'message' => 'Business updated successfully.',
    //             'business' => $business
    //         ], 200);
    //     } catch (\Exception $e) {
    //         Log::error('Business update error: ' . $e->getMessage());

    //         return response()->json([
    //             'message' => 'An error occurred while updating the business.'
    //         ], 500);
    //     }
    // }

    public function updatebusiness(Request $request, $id)
    {
        try {
            // Decrypt ID if encrypted
            $decryptedId = Crypt::decrypt($id);

            // 🔍 Find the business that belongs to the logged-in user
            $business = Business_list::where('owner_id', Auth::id())
                ->where('id', $decryptedId)
                ->first();

            if (!$business) {
                return response()->json([
                    'message' => 'Business not found.'
                ], 404);
            }

            // ✅ Validate incoming data
            $validatedData = $request->validate([
                'business_name' => 'sometimes|string|max:255',
                'industry_type' => 'sometimes|string|max:255',
                'website' => 'nullable|url|max:255',
                'phone' => 'nullable|string|max:20',
                'state' => 'nullable|string|max:255',
                'city' => 'nullable|string|max:255',
                'country' => 'nullable|string|max:255',
                'address' => 'nullable|string|max:500',
                'currency' => 'nullable|string|max:10',
                'about_business' => 'nullable|string',
                'description' => 'nullable|string',
                'logo' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            ]);

            // 🖼️ Handle logo upload (if provided)
            if ($request->hasFile('logo')) {
                // 🧹 Remove previous logo if it exists
                if ($business->logo && Storage::disk('public')->exists($business->logo)) {
                    Storage::disk('public')->delete($business->logo);
                }

                // 📤 Upload new logo
                $file = $request->file('logo');
                $path = $file->store('business_logo', 'public');
                $validatedData['logo'] = $path;
            }

            // 💾 Update business record
            $business->update($validatedData);

            return response()->json([
                'message' => 'Business updated successfully.',
                'business' => $business
            ], 200);
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            return response()->json([
                'message' => 'Invalid business ID.'
            ], 400);
        } catch (\Exception $e) {
            Log::error('Business update error: ' . $e->getMessage());

            return response()->json([
                'message' => 'An error occurred while updating the business.'
            ], 500);
        }
    }




    public function deleteBusiness(Request $request, $id)
    {
        try {
            //Decrypt ID if you encrypt IDs in URLs
            $decryptedId = Crypt::decrypt($id);

            // Find business owned by the logged-in user
            $business = Business_list::where('owner_id', Auth::id())
                ->where('id', $decryptedId)
                ->first();

            if (!$business) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Business not found or unauthorized.',
                ], 404);
            }

            // 🖼️ Delete logo file if it exists
            if ($business->logo && Storage::exists($business->logo)) {
                Storage::delete($business->logo);
            }

            //Delete the business record
            $business->delete();

            return response()->json([
                'status' => 'success',
                'message' => 'Business and its logo deleted successfully.',
            ], 200);
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid business ID provided.',
            ], 400);
        } catch (\Exception $e) {
            Log::error('Business deletion error: ' . $e->getMessage());

            return response()->json([
                'status' => 'error',
                'message' => 'An unexpected error occurred while deleting the business.',
            ], 500);
        }
    }


    // public function suspendBusiness(Request $request, $id)
    // {
    //     try {
    //         // Decrypt ID if you encrypt IDs
    //         $decryptedId = Crypt::decrypt($id);

    //         // 🔍 Find the business owned by the logged-in user
    //         $business = Business_list::where('owner_id', Auth::id())
    //             ->where('id', $decryptedId)
    //             ->first();

    //         if (!$business) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => 'Business not found or unauthorized.',
    //             ], 404);
    //         }

    //         // ✅ Validate input
    //         $validated = $request->validate([
    //             'status' => 'required|string|in:active,inactive,suspended',

    //         ]);

    //         // 📝 Update business status and optional reason
    //         $business->status = $validated['status'];

    //         $business->save();

    //         return response()->json([
    //             'status' => 'success',

    //         ], 200);
    //     } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => 'Invalid business ID provided.',
    //         ], 400);
    //     } catch (\Exception $e) {
    //         Log::error('Business suspend error: ' . $e->getMessage());

    //         return response()->json([
    //             'status' => 'error',
    //             'message' => 'An error occurred while updating business status.',
    //         ], 500);
    //     }
    // }


    public function suspendBusiness(Request $request, $id)
    {
        try {
            //Decrypt the business ID (remove if you’re not encrypting IDs)
            $businessId = Crypt::decrypt($id);

            //Find the business that belongs to the authenticated user
            $business = Business_list::where('owner_id', Auth::id())
                ->where('id', $businessId)
                ->first();

            if (!$business) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Business not found or unauthorized.',
                ], 404);
            }

            //Validate the status input
            $validated = $request->validate([
                'status' => 'required|string|in:active,inactive,suspended',
            ]);

            //Update the status
            $business->update(['status' => $validated['status']]);

            return response()->json([
                'status' => 'success',
                'message' => "Business status updated to '{$validated['status']}'.",
                'business' => $business,
            ], 200);
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid business ID provided.',
            ], 400);
        } catch (\Exception $e) {
            Log::error('Business suspend error: ' . $e->getMessage());

            return response()->json([
                'status' => 'error',
                'message' => 'An unexpected error occurred while updating business status.',
            ], 500);
        }
    }
}
