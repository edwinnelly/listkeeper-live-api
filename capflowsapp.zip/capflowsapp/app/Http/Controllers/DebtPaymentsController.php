<?php

namespace App\Http\Controllers;

use App\Models\Debt_payments;
use Illuminate\Http\Request;

class DebtPaymentsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Debt_payments $debt_payments)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Debt_payments $debt_payments)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Debt_payments $debt_payments)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Debt_payments $debt_payments)
    {
        //
    }
}
