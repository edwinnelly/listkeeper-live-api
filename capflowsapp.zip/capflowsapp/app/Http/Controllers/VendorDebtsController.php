<?php

namespace App\Http\Controllers;

use App\Models\Vendor_debts;
use Illuminate\Http\Request;

class VendorDebtsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Vendor_debts $vendor_debts)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Vendor_debts $vendor_debts)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Vendor_debts $vendor_debts)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Vendor_debts $vendor_debts)
    {
        //
    }
}
