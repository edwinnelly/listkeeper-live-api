<?php

namespace App\Http\Controllers;

use App\Models\Services_categories;
use Illuminate\Http\Request;

class ServicesCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Services_categories $services_categories)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Services_categories $services_categories)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Services_categories $services_categories)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Services_categories $services_categories)
    {
        //
    }
}
