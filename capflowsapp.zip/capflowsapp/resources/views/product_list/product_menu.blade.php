<ul>
    <li><a href="{{ route('products.index') }}">Products</a></li>
    <li><a href="{{ route('sublocation_products.items') }}" class="active">Locations
            Products</a></li>
    <li><a href="{{ route('products.category.index') }}">Categories</a></li>
    <li><a href="{{ route('products.unit.index') }}">Units</a></li>
    <li><a href="{{ route('products.all.keys') }}">Serial Trackers</a></li>
</ul>
